Test text in a test file
