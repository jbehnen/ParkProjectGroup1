package park_model;

public enum WorkCategory {
	LIGHT, MEDIUM, HEAVY;
}
