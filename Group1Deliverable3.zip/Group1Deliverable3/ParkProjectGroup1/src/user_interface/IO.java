package user_interface;

public interface IO {
	public void mainMenu();
}
